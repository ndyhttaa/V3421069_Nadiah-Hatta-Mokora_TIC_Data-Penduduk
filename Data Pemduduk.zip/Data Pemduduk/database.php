<?php
class Database
{
    private $dbhost;
    private $dbuser;
    private $dbpass;
    private $dbname;

    function __construct($db_host, $db_user, $db_password, $db_name)
    {
        $this->dbhost = $db_host;
        $this->dbuser = $db_user;
        $this->dbpass = $db_password;
        $this->dbname = $db_name;
    }

    function conn_mysql()
    {
        $connect_db = mysqli_connect($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname);
        return $connect_db;
    }
}
$db = new Database('127.0.0.1', 'root', '', 'backend');
$koneksi = $db->conn_mysql();